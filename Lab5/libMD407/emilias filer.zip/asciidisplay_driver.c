/*
 * libMD407
 * asciidisplay_driver.c
 * Display connected to PE
 * Driver for ASCIIDISPLAY
 */
 
 
#include "libmd407.h"
static int asciidisplay_init( int initval );
static void asciidisplay_deinit( int deinitval);
static int asciidisplay_write(char *ptr, int len);
DEV_DRIVER_DESC AsciiDisplay = {
    {"AsciiDisplay"},
    asciidisplay_init,
    asciidisplay_deinit,
    0,
    0,
    0,
    0,
    0,
    asciidisplay_write,
    0
};
/* ASCIIDISPLAY types and constants definitions */
 // för delay//
#define     SIMULATOR 
 
#define     STK_CTRL ((volatile unsigned int *)(0xE000E010))
#define     STK_LOAD ((volatile unsigned int *)(0xE000E014))
#define     STK_VAL ((volatile unsigned int *)(0xE000E018)) 
 
 // från uppgift labb 2.3 //
#define B_E            0x40                /* Enable-signal */
#define B_SELECT        4                   /* Select ASCII-display */
#define B_RW            2                   /* 0=Write, 1=Read */
#define B_RS            1                   /* 0=Control, 1=Data */
#define GPIO_E          0x40021000           /* MD407 port E */

      
#define GPIO_E_MODER      ((volatile unsigned int *) GPIO_E)
#define portOtyper      ((volatile unsigned short *) GPIO_E+0x04)
#define portOspeedr     ((volatile unsigned long *) GPIO_E+0x08)
#define portPupdr       ((volatile unsigned long *) GPIO_E+0x0C)

#define portIdrLow      ((volatile unsigned char *) GPIO_E+0x10)
#define GPIO_E_IDRHIGH     ((volatile unsigned char *) GPIO_E+0x11)

#define GPIO_E_ODRLOW      ((volatile unsigned char *) GPIO_E+0x14)
#define GPIO_E_ODRHIGH     ((volatile unsigned char *) GPIO_E+0x15)

// definitioner av funktioner för ascii //
void ascii_gotoxy(int x, int y);
void ascii_write_char(unsigned char us);
void ascii_ctrl_bit_set( unsigned char x );
void ascii_ctrl_bit_clear( unsigned char x );
unsigned char ascii_read_controller( void );
unsigned char ascii_read_status();
void ascii_command (command);
void ascii_write_controller( char c );
void ascii_write_cmd (unsigned char command);
void ascii_write_data (unsigned char data);
unsigned char ascii_read_data (void);


// delay funktioner //
void delay_mikro (unsigned int us){
    
    while( us > 0 ){
    delay_250ns();
    delay_250ns();
    delay_250ns();
    delay_250ns();
    us--;
    }
}

void delay_250ns (void){
    /* SystemCoreClock = 168000000 */
    *STK_CTRL = 0;
    *STK_LOAD = ( (168/4) -1 );
    *STK_VAL = 0;
    *STK_CTRL = 5;
    while( (*STK_CTRL & 0x10000 )== 0 );
    *STK_CTRL = 0;
}

void delay_milli (unsigned int ms){

    
    #ifdef  SIMULATOR
    ms = ms /1000;
    ms++;
    #endif
    
    ms = ms*1000;
    delay_mikro(ms);
}


/* Define functions here */
static int asciidisplay_init( int initval ){
    *GPIO_E_MODER = 0x55555555;
   ascii_ctrl_bit_clear(B_RS); 
   ascii_ctrl_bit_clear(B_RW);
   ascii_command(0x38);
   ascii_command(0xF);
   ascii_command(1);
   ascii_command(6);
   
}

// ascii funktioner //
void ascii_gotoxy(int x, int y){
    int adress;
    adress = x-1;
    if (y ==2){
        adress = adress + 0x40;
    }
    ascii_write_cmd(0x80 | adress);
}

void ascii_write_char(unsigned char us){
   
while ((ascii_read_status() & 0x80)==0x80);
delay_mikro(8);
ascii_write_data(us);
delay_mikro(43);
}

void ascii_ctrl_bit_set( unsigned char x ){
char c;
c = *GPIO_E_ODRLOW;
*GPIO_E_ODRLOW = B_SELECT | x | c;
}

void ascii_ctrl_bit_clear( unsigned char x ){
char c;
c = *GPIO_E_ODRLOW;
c = c & ~x;
*GPIO_E_ODRLOW = B_SELECT | c;
}

unsigned char ascii_read_controller( void ){
char c;
ascii_ctrl_bit_set( B_E );
delay_250ns();
delay_250ns();
c = *GPIO_E_IDRHIGH;
ascii_ctrl_bit_clear( B_E );
return c;
}

unsigned char ascii_read_status(){
char c;
*GPIO_E_MODER = 0x00005555;
ascii_ctrl_bit_set( B_RW );
ascii_ctrl_bit_clear( B_RS );
c = ascii_read_controller();
*GPIO_E_MODER = 0x55555555;
return c;
}

void ascii_command (command){
    
while ((ascii_read_status() & 0x80)==0x80);
delay_mikro(8);
ascii_write_cmd(command);
    if (command == 1){
       delay_milli(2);
    }
    if(  ((command & 4 ) == 4 )|| ((command & 8)== 8) || ((command & 48) == 48) ) {
        delay_mikro(39);
    }
}

void ascii_write_controller( char c ){
ascii_ctrl_bit_set( B_E );
*GPIO_E_ODRHIGH = c;
ascii_ctrl_bit_clear( B_E );
delay_250ns();
}

void ascii_write_cmd (unsigned char command){
 
ascii_ctrl_bit_clear (B_RS);
ascii_ctrl_bit_clear (B_RW);
ascii_write_controller(command);
   
}

void ascii_write_data (unsigned char data){
    
ascii_ctrl_bit_set (B_RS);    
ascii_ctrl_bit_clear (B_RW);
ascii_write_controller(data);    
    
}

unsigned char ascii_read_data (void){
 char c;   
*GPIO_E_MODER = 0x00005555;
ascii_ctrl_bit_set( B_RS );
ascii_ctrl_bit_set( B_RW );
c = ascii_read_controller();
*GPIO_E_MODER = 0x55555555;
return c;
    
}

// nya funkioner //
static void asciidisplay_deinit( int deinitval){
    }
    
static int asciidisplay_write(char *ptr, int len){ 
    while (*ptr) {
        ascii_write_char(*ptr++);
    }
 } 